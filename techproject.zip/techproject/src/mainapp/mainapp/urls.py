"""mainapp URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls import include #this addition gives access to the include() function that we use below in urlpatterns
from django.contrib import admin
from django.urls import path
from . import views #the directory of . is our current directory (mainapp)
#so the above says import views.py from the current mainapp directory
#ANATOMY OF A URL ROUTE:
#('pattern to watch for',method to call,"shortcut name")
urlpatterns = [
    path('', views.home, name="home"),
    path('admin/', admin.site.urls),
    path('', include('products.urls')),#enables recognition by django of the urls.py file within the products directory
                                        #we had to create the urls.py file within products directory ourselves

]
urlpatterns += staticfiles_urlpatterns() #so we are adding to what this variable already
#stores above (the paths)
"""URL patterns are patterns within URLs that indicate which functions django should run
in order to paint the appropriate content or page on the user's browser. There is a list of 
patterns X,Y,Z, ... of URLs that correlate with specific functions which generate specific 
content to display to the user. The URL : FUNCTION mapping is stored under urlpatterns above.

When a user types in a URL on our webpage, django doesn't understand that. Django uses functions.
So a 'middle man' switchboard type thing is used to translate X URL = X FUNCTION = X CONTENT, etc.

The web browser talks to the urlpatterns and sees 'admin/' above, which means call admin.site.urls function,
for example. """