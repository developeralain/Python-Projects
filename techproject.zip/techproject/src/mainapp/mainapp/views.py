from django.http import HttpResponse
#above, we are importing the HttpResponse object from the http module
#we are going to create an HttpResponse object, which responds to a user's
#HttpRequest object
from django.shortcuts import render

#these views pertain to the home page ONLY...
#each app has a purpose and we don't go beyond that purpose...
#in this views file, we only address views pertaining to serving the home page only.


#we will return an HttpResponse to our users

#this says what to do when home is invoked
def home(request):#the request parameter is needed as we need a request object
    products = ["Cherries","Apples","Oranges","Strawberries","Pears","Watermelons"]
    context = {
        'products': products,
    }
    #from the user before we can provide an HttpResponse object to them
    return render(request, "home.html", context)
#the render function renders a web page. We pass in arguments:
#the HttpRequest object
#the web page file we would like to have rendered
#a dictionary object {} ... this is the context variable which houses our dic



