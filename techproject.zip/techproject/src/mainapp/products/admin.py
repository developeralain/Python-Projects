from django.contrib import admin

# Register your models here.

#here we are registering Product from models.py in two steps: first we import then we register...

#step1: import product
from .models import Product #now it knows how to access our Product model from models.py

#step2: register product
admin.site.register(Product) #this is all that is needed to tell our admin software how to manage our product module


#one last step: go to settings.py of mainapp and tell our mainapp that there's a new application installed.
#line 41 of settings.py you'll find INSTALLED APPS, add it to the list there per the title of the app (products)