from django.shortcuts import render
from django.http import HttpResponse
from .models import Product
#we use this views file when we want to do anything associated with the products


# Create your views here.

def admin_console(request):
    #products is where we'll stored the info we get from our dB
    products = Product.object.all()
    return render(request, 'products/products_page.html', ('products', products))
