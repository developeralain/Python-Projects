from django.db import models

"""when we say models, we mean DATABASE! It is the database schema, the modeled schema (A structure for organizing and classifying
 data in a database. It defines data contents and relationships. Very similar to concept of data model. ) for our
  database—of how it’s actually going to work
"""
# Create your models here.

#you don't need to specify a primary key / id as this is done automatically by DJANGO

#this is a dictionary, which consists of key/value pairs contained within
#tuples ( )
TYPE_CHOICES = {
    ('appetizers','appetizers'),
    ('entrees','entrees'),
    ('treats','treats'),
    ('drinks','drinks')
}
#the above dictionary presents options for the staff, who can choose
#to create an object to sell to a customer
#the above allows us to control the data, to prevent mispellings etc.
#as choices as limited.


#this is our database file (models.py)
#the objects we create here allow us to communicate with the database

#below is our basic model --our basic schema--for a product
#whenever they create a product, these are the fields that must be filled out with information
class Product(models.Model):
    type = models.CharField(max_length=60, choices=TYPE_CHOICES)
    name = models.CharField(max_length=60, default="", blank=True, null=False)
    #for name we are saying max length is 60 characters, default value is empty
    #for name, blank=True means that the user does not HAVE to type anything into this field
    #for name, null=False means if the user goes to save the form, we NEED a value to be there
    #on our webpage the user may not type anything into name (blank=True) but they will eventually need to
    #in order to proceed (null = False; won't let them enter a blank value into the database).
    description = models.TextField(max_length=300, default="", blank=True)
    price = models.DecimalField(default=0.00, max_digits=10000, decimal_places=2)
    image = models.CharField(max_length=255, default='', blank=True)

    object = models.Manager()

    #below function changes the name we see in the browser for a product
    #to be the name attribute of our object, rather than the default which
    #in this case would be Product object(1) and isn't very descriptive
    def __str__(self):
        return self.name

#now that you created Product, you must register your app. Go to admin.py file